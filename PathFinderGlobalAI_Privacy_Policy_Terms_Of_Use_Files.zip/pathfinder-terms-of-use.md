# Terms of Use — PathFinderGlobal AI

**Effective date:** July 7, 2026

These Terms of Use ("Terms") are a legal agreement between you and
PathFinderGlobal AI ("we," "us," "our") governing your use of the
PathFinderGlobal AI mobile application (the "App"). By creating an
account or using the App, you agree to these Terms.

---

## 1. Eligibility

You must be at least 13 years old (or the minimum age of digital
consent in your country) to use the App. If you are under 18, you
confirm you have a parent or guardian's permission to use the App and
to make any purchases.

---

## 2. Your Account

You're responsible for maintaining the confidentiality of your account
credentials and for all activity under your account. Notify us
immediately if you suspect unauthorized use.

---

## 3. Photos and Voice Samples You Provide

### 3.1 Your representation and warranty
By uploading a photo or recording a voice sample, **you confirm that:**
- The photo is a photo of yourself, taken with your consent, or of
  another person who has given you explicit permission to use their
  likeness in the App
- The voice sample is your own voice, recorded with your consent
- You will not upload content depicting anyone under 18 for the purpose
  of generating altered imagery, or content you do not have the right
  to use

We rely on this representation to provide the service. Violating it may
result in immediate account termination and, where applicable, being
reported to the relevant authorities.

### 3.2 License you grant us
You grant us a limited, non-exclusive license to process your uploaded
photo and voice sample solely to generate your requested AI content
(career images and voice clips) and to provide the App's core
functionality, including sending this data to our AI service providers
(fal.ai for image generation, ElevenLabs for voice cloning) as described
in our Privacy Policy. This license ends when you delete your account or
the specific content, except where retention is required by law.

---

## 4. Generated Content

### 4.1 What you get
Once you unlock a generation, we grant you a personal, non-commercial
license to use, download, and share the AI-generated image and audio
clip we create for you, including via the App's built-in share feature
(which adds a "Created with PathFinderGlobal AI" watermark to shared
copies).

### 4.2 AI-generated content disclaimer
Generated images and audio are created by third-party AI models and are
**approximations**, not guaranteed-accurate representations of you or
any real-world scenario. Results may vary in accuracy, likeness
fidelity, and quality. The App is intended for entertainment and
self-visualization purposes and should not be relied upon for any
professional, medical, legal, or career-decision purpose.

### 4.3 Our rights
We do not claim ownership of your uploaded photos or voice samples. We
may use anonymized, aggregated data about App usage (not your personal
photos, voice, or generated content) to improve the App.

---

## 5. Subscriptions and Purchases

### 5.1 One-time unlocks and subscriptions
The App offers a one-time purchase to unlock a full career generation,
and/or a subscription for ongoing access. Prices are shown in the App
before purchase and are processed through the Apple App Store or Google
Play.

### 5.2 Auto-renewal terms (required disclosure)
- Subscription payment will be charged to your Apple ID or Google
  Play account at confirmation of purchase.
- Subscriptions automatically renew unless auto-renew is turned off at
  least 24 hours before the end of the current period.
- Your account will be charged for renewal within 24 hours prior to the
  end of the current period, at the same price you agreed to at
  purchase unless the price has changed and you have been notified as
  required by law.
- You can manage and cancel subscriptions by going to your App Store or
  Google Play account settings after purchase. Cancelling deletion of
  the app does not cancel a subscription.
- No cancellation of the current subscription is allowed during the
  active subscription period; any unused portion of a free trial period,
  if offered, will be forfeited when you purchase a subscription.

### 5.3 Refunds
Refund requests are handled by Apple or Google under their respective
refund policies, not directly by us, since they process the payment.

---

## 6. Acceptable Use

You agree not to:
- Use the App to create content that is illegal, harassing,
  defamatory, or infringes another person's rights
- Upload another person's photo or voice without their consent
- Attempt to reverse-engineer, scrape, or interfere with the App or its
  underlying AI services
- Use generated content to impersonate someone in a misleading or
  harmful way (e.g., presenting AI-generated content as a real,
  unaltered photo or recording without disclosure)

We may suspend or terminate accounts that violate this section.

---

## 7. Disclaimer of Warranties

THE APP AND ALL GENERATED CONTENT ARE PROVIDED "AS IS" AND "AS
AVAILABLE," WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED,
INCLUDING WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE, OR NON-INFRINGEMENT. WE DO NOT WARRANT THAT GENERATED CONTENT
WILL BE ACCURATE, UNINTERRUPTED, OR ERROR-FREE.

---

## 8. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, PATHFINDERGLOBAL AI SHALL NOT BE
LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE
DAMAGES, OR ANY LOSS OF DATA, GOODWILL, OR EMOTIONAL DISTRESS, ARISING
FROM YOUR USE OF THE APP OR ANY AI-GENERATED CONTENT, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES. OUR TOTAL LIABILITY FOR ANY CLAIM
RELATED TO THE APP SHALL NOT EXCEED THE AMOUNT YOU PAID US IN THE 12
MONTHS BEFORE THE CLAIM AROSE.

Some jurisdictions do not allow the exclusion or limitation of certain
damages, so some of the above limitations may not apply to you.

---

## 9. Indemnification

You agree to indemnify and hold us harmless from any claims, damages, or
expenses arising from your violation of these Terms, your uploaded
content, or your misuse of generated content.

---

## 10. Termination

You may delete your account at any time. We may suspend or terminate
your access if you violate these Terms. Upon termination, your license
to use generated content you've already downloaded survives, but access
to the App and cloud-stored content ends.

---

## 11. Changes to These Terms

We may update these Terms from time to time. Continued use of the App
after changes take effect constitutes acceptance of the updated Terms.

---

## 12. Governing Law

These Terms are governed by the laws of New Providence, Nassau,
Bahamas, without regard to conflict of law principles. Should
PathFinderGlobal AI relocate its legal jurisdiction, this section will
be updated accordingly.

---

## 13. Contact Us

Questions about these Terms:

**jappaenterprises7@gmail.com**

